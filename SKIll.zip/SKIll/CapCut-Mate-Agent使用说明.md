---
name: capcut-mate
description: Create or revise editable Jianying/CapCut video drafts from user-provided video, image, audio, and text assets, including captions, filters, transitions, masks, stickers, and keyframe animation. Use for automatic or polished video-editing requests that should use the locally installed CapCut Mate service. Do not use for merely playing or summarizing a video.
---

# CapCut Mate video editing

Use the bundled CapCut Mate v8.0.83 service through scripts in this plugin. It is a draft-automation system, not an autonomous taste engine: first infer or state a coherent edit direction from the user's goal, audience, platform, and assets, then translate that direction into timeline operations.

## Local installation

- Plugin root: `/Users/fengtianzhu/plugins/capcut-mate`
- Upstream source: `vendor/capcut-mate`
- Isolated Python: `.venv/bin/python`
- Local API: `http://127.0.0.1:30000/openapi/capcut-mate/v1`
- Start with `scripts/start.sh`; inspect with `scripts/status.sh`; stop with `scripts/stop.sh`.
- The service must stay bound to `127.0.0.1`. Do not expose it on `0.0.0.0`.

## Editing workflow

1. Preserve every source asset. Never overwrite, move, or delete user media.
2. Inspect durations, dimensions, frame rate, orientation, audio presence, and representative frames before designing the edit. Use `ffprobe`/`ffmpeg` when available.
3. Decide the story and pacing before adding decoration. Prefer motivated cuts and a small, consistent visual language over applying every effect.
4. Start the local service and verify `/docs` responds.
5. Read only the relevant endpoint documentation under `vendor/capcut-mate/docs/`. Use the API for draft creation, videos/images/audio, captions, filters, effects, masks, stickers, and keyframes.
6. For local media, expose only the directory containing the selected assets through a temporary localhost-only HTTP server. Stop it when the draft is complete.
7. Save the result as a new draft with a descriptive name. On macOS, expect the reliable endpoint to be an editable Jianying draft; automated final export is Windows-oriented.
8. Report what was created, the creative choices made, any unsupported effects, and how the user can open the draft in Jianying.

## Creative defaults

- Match the requested platform; when unspecified, preserve the dominant source orientation.
- For short social video, establish the subject quickly, cut on action or musical accents, use restrained punch-ins, and keep captions inside safe margins.
- Use keyword highlighting selectively. Keep typography, color palette, transition family, and motion curves consistent.
- Avoid rapid flashing, excessive zooms, or distracting transitions unless explicitly requested.
- Treat copyrighted music and paid Jianying assets as user-controlled resources; do not bypass licenses or paywalls.

## Safety boundaries

- Disable API-key billing and cloud-object-storage features unless the user explicitly requests and configures them.
- Do not call repository utility scripts that contain third-party tokens.
- Do not use the unsigned desktop DMG or third-party Docker images.
- Ask before any final export that could incur cloud charges or overwrite an existing draft.
- If an API operation might clean up drafts or terminate Jianying, do not invoke it on macOS; create and save a new draft instead.

