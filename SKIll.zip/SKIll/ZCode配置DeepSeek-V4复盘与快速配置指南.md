# ZCode 接入 DeepSeek V4：复盘 + 快速配置指南

> 适用电脑：本机（Mac，ZCode 3.10.1，应用装在桌面 `~/Desktop/ZCode.app`）
> 更新日期：2026-09-08
> 结论：现在 DeepSeek 下已配好两个模型，全部可用（`deepseek-v4-pro` + `deepseek-v4-flash-vision-exp` 视觉模型）。

---

## 一、复盘：第一次为什么没配好？

### 一句话结论

第一次配置失败，是因为我把供应商 ID 写成了 **`builtin:deepseek`**。ZCode 把 `builtin:` 开头的供应商一律当作"智谱内置供应商"处理，而内置白名单里根本没有 DeepSeek，于是它在构建模型注册表时被**静默丢弃**。改成 `custom:` 前缀后，重启一次就成功了。

### 具体过程（有日志和代码为证）

1. **第一次配好后**：ZCode 界面模型选择器**能看到** `DeepSeek / deepseek-v4-pro`——因为界面直接读配置文件，不做前缀校验。
2. **但一用就报错**："当前使用的模型已不可用，请从当前模型列表中选择一个可用模型后继续"。
3. **日志铁证**（`~/.zcode/v2/logs/2026-09-08.log`）：
   - 反复出现 `历史 session 模型已不可用，拒绝按默认模型恢复 {"modelId":"deepseek-v4-pro","providerId":"builtin:deepseek",...}`
   - 配置里明明有 7 个供应商，注册表却只加载了 1 个（`providerCount: 1`）——DeepSeek 在进注册表前就被过滤掉了
4. **代码级根因**（从 ZCode 应用包逆向确认）：
   - 规则 1：ID 以 `builtin:` 开头 → 按内置供应商处理
   - 规则 2：内置供应商白名单只有 `zai / bigmodel / zapi` 等 7 个，**没有 deepseek**
   - 规则 3：注册表构建时，白名单外的 `builtin:` 供应商被丢弃；而 `custom:` 前缀的自定义供应商会放行
   - 于是出现"**界面能看到、运行时找不到**"的错位，反复重启也没用（因为 ID 前缀错误一直存在）

### 核心教训

| 教训 | 说明 |
|---|---|
| 供应商 ID 前缀 | 自定义供应商必须用 `custom:` 前缀；`builtin:` 是智谱内置专属 |
| 改完必须重启 | 模型注册表只在 ZCode 启动时构建，运行中改文件不会热加载 |
| 界面显示 ≠ 可用 | 界面读配置文件、运行时用注册表，两者会不一致 |
| 改前先备份 | 任何配置修改前先备份 `config.json` |
| 验证看日志 | 以日志里的 `providerCount / modelCount / session/resume` 为准，别只看界面 |

---

## 二、快速配置指南（下次 1 分钟搞定）

### 方法 A：一键脚本（推荐）

已做成本机技能，脚本位置：

```
~/Library/Application Support/Doubao/Default/.doubao/agent_mode/workspace/.user_skills/zcode-deepseek-setup/scripts/setup_deepseek.py
```

用法（把 `sk-xxx` 换成 API key）：

```bash
python3 "<上面的脚本路径>" --api-key sk-xxx --restart
```

脚本自动完成：备份配置 → 写入 DeepSeek 供应商（含两个模型）→ 校验 → 退出 ZCode → 确认配置没被覆盖 → 重新启动。幂等，可反复执行。

### 方法 B：手动改配置（脚本不可用时的备选）

1. 备份：`cp ~/.zcode/v2/config.json ~/.zcode/v2/config.json.bak-<日期>`
2. 用任意编辑器打开 `~/.zcode/v2/config.json`，在 `"provider"` 对象里加：

```json
"custom:deepseek": {
  "name": "DeepSeek",
  "kind": "anthropic",
  "options": {
    "apiKey": "sk-你的key",
    "baseURL": "https://api.deepseek.com/anthropic"
  },
  "enabled": true,
  "source": "custom",
  "models": {
    "deepseek-v4-pro": {
      "reasoning": {"enabled": true, "variants": ["low","max","high"], "defaultVariant": "max"},
      "limit": {"context": 1000000, "output": 384000},
      "modalities": {"input": ["text"], "output": ["text"]},
      "zcode": {"modified": false, "priority": 98}
    },
    "deepseek-v4-flash-vision-exp": {
      "reasoning": {"enabled": true, "variants": ["low","max","high"], "defaultVariant": "max"},
      "limit": {"context": 1000000, "output": 384000},
      "modalities": {"input": ["text","image"], "output": ["text"]},
      "zcode": {"modified": false, "priority": 97}
    }
  }
}
```

3. 校验 JSON：`python3 -c "import json; json.load(open('/Users/fengtianzhu/.zcode/v2/config.json'))"`
4. 重启：`osascript -e 'quit app "ZCode"'` → 等 4 秒 → 确认 deepseek 还在 → `open ~/Desktop/ZCode.app`

### 验证是否成功

重启后等 14 秒，查日志：

```bash
grep -E "providerCount|modelCount" ~/.zcode/v2/logs/2026-09-08.log | tail
```

期望：`providerCount: 2`、`modelCount: 4`，且不再出现"模型已不可用"。

---

## 三、DeepSeek 官方参数速查

| 项 | 值 |
|---|---|
| Anthropic 接口 | `https://api.deepseek.com/anthropic` |
| OpenAI 接口 | `https://api.deepseek.com` |
| 文本模型 | `deepseek-v4-pro`（1M 上下文 / 384K 输出） |
| 视觉模型 | `deepseek-v4-flash-vision-exp`（支持 JPG/PNG/GIF/WebP） |
| 旧模型名 | `deepseek-chat`、`deepseek-reasoner`（2026-07-24 已弃用，别再用） |

API key 自查：`curl https://api.deepseek.com/models -H "Authorization: Bearer sk-xxx"`（200=有效，401=key 错，402=余额不足）。

---

## 四、常见问题

- **旧会话报"模型不可用"**：该会话记录的是旧 ID（builtin:deepseek），开新任务或在会话里重新选一次模型即可。
- **界面能看到、一用就报错**：检查 provider ID 是不是 `custom:` 开头（90% 是这个原因）。
- **改完没生效**：没完全重启 ZCode，注册表只在启动时构建。
- **给 v4-pro 发图报错**：只有视觉模型能收图，这是官方限制，不是配置问题。

---

## 五、本次成果清单

| 项目 | 位置 |
|---|---|
| 技能（含脚本+复盘+参数） | `~/.zcode/.../workspace/.user_skills/zcode-deepseek-setup/` |
| 本文档 | 桌面 |
| 配置备份 | `~/.zcode/v2/config.json.bak-*`（多次备份） |
| 当前可用模型 | `deepseek-v4-pro`、`deepseek-v4-flash-vision-exp` |
