# 在 ZCode 上接入硅基流动免费送的 16 元 Deepseek 的 API 方法

> 适用电脑：本机（Mac，ZCode 3.10.1）
> 更新日期：2026-09-09
> 状态：已实测可用（硅基流动 16 元代金券 + `deepseek-ai/DeepSeek-V4-Flash`）

---

## 一、前置准备

1. 在 https://cloud.siliconflow.cn 注册账号，领取新人免费额度（16 元代金券）
2. 打开 https://cloud.siliconflow.cn/account/ak 新建 API 密钥，点「复制」完整拷贝（别手动框选，容易漏字符）
3. 确认右上角余额里代金券已到账

> key 自查：`curl https://api.siliconflow.cn/v1/models -H "Authorization: Bearer sk-你的key"`，返回模型列表 = 有效；返回 `Token is invalid` = key 无效或复制不完整。

## 二、两个必须知道的规则（不看会踩坑）

| 规则 | 内容 |
|---|---|
| ① 供应商 ID 用 `custom:` 前缀 | `builtin:` 是 ZCode 内置供应商（智谱系）专属，写 `builtin:` 会被静默丢弃：界面能看到、一用就报错 |
| ② `kind` 必须写 `openai-compatible` | 写 `openai` 会走 OpenAI Responses 接口（硅基流动不支持）→ 报 `Model request failed`；`openai-compatible` 才走硅基流动支持的 Chat Completions 接口 |

规则 ② 是本机实测踩过的坑：第一次配成 `kind: "openai"`，界面能选、发消息就失败；改成 `openai-compatible` 后一次通过。

## 三、方法 A：一键脚本（推荐）

脚本已安装为技能，绝对路径：

```
/Users/fengtianzhu/Library/Application Support/Doubao/Default/.doubao/agent_mode/workspace/.user_skills/zcode-siliconflow-setup/scripts/setup_siliconflow.py
```

执行（把 `sk-xxx` 换成你的 key）：

```bash
python3 "/Users/fengtianzhu/Library/Application Support/Doubao/Default/.doubao/agent_mode/workspace/.user_skills/zcode-siliconflow-setup/scripts/setup_siliconflow.py" --api-key sk-xxx --restart
```

自动完成：备份配置 → 写入供应商 → 校验 → 退出 ZCode → 确认没被覆盖 → 重启。幂等，可反复执行（只会更新 key）。

## 四、方法 B：手动配置

1. 备份：`cp ~/.zcode/v2/config.json ~/.zcode/v2/config.json.bak-siliconflow`
2. 编辑 `~/.zcode/v2/config.json`，在 `"provider"` 对象里加：

```json
"custom:siliconflow": {
  "name": "SiliconFlow",
  "kind": "openai-compatible",
  "options": {
    "apiKey": "sk-你的key",
    "baseURL": "https://api.siliconflow.cn/v1"
  },
  "enabled": true,
  "source": "custom",
  "models": {
    "deepseek-ai/DeepSeek-V4-Flash": {
      "reasoning": { "enabled": true, "variants": ["low", "max", "high"], "defaultVariant": "max" },
      "limit": { "context": 1000000, "output": 384000 },
      "modalities": { "input": ["text"], "output": ["text"] },
      "zcode": { "modified": false, "priority": 95 }
    }
  }
}
```

3. 校验：`python3 -c "import json; json.load(open('/Users/fengtianzhu/.zcode/v2/config.json'))"`
4. 重启 ZCode：`osascript -e 'quit app "ZCode"' && sleep 4 && open ~/Desktop/ZCode.app`

## 五、验证是否成功

1. 打开 ZCode，**新建会话**，模型选 `SiliconFlow / deepseek-ai/DeepSeek-V4-Flash`
2. 发条消息能正常回复 = 成功
3. 更硬的验证（重启后查日志）：

```bash
grep -a "providerCount" ~/.zcode/v2/logs/$(date +%F).log | tail -2
```

`providerCount` 比原来多 1、`modelCount` 多 1，且日志中该模型的 `apiFormat` 为 `openai-chat-completions` = 配置正确。

## 六、参数速查

| 项 | 值 |
|---|---|
| Base URL | `https://api.siliconflow.cn/v1` |
| 模型 ID | `deepseek-ai/DeepSeek-V4-Flash`（1M 上下文 / 384K 输出） |
| 其他可用模型 | `deepseek-ai/DeepSeek-V4-Pro` 等 |
| 与 DeepSeek 官方的区别 | 硅基流动是 OpenAI 兼容接口；DeepSeek 官方是 Anthropic 接口，两者可在 ZCode 共存 |

## 七、常见问题

| 现象 | 原因 / 解决 |
|---|---|
| `Model request failed` | 90% 是 `kind` 写成 `openai`，改成 `openai-compatible` 并重启 |
| 界面能看到、一用就报错 | provider ID 不是 `custom:` 前缀 |
| `Token is invalid` | key 复制不完整，回控制台重新复制；确认代金券已到账 |
| 改完没生效 | 没完整重启 ZCode（注册表只在启动时构建） |
| 旧会话还报错 | 新建会话或重选一次模型 |

## 八、本次踩坑复盘（一句话版）

第一次配失败是因为 `kind` 用了 `openai`，ZCode 就向硅基流动不支持的 `/v1/responses` 接口发请求；ZCode 里 `kind` 有三种取值（`anthropic` / `openai` / `openai-compatible`），第三方 OpenAI 兼容服务一律用 `openai-compatible`。
