---
name: horizontal-bigfont-algebra-animation
description: 横屏大字 Manim 代数动画标准 — 16:9 横屏、大字粗体公式、≤4 行均匀分布、暗色主题、中文+公式 VGroup 混排、图像+推导双模。Use when writing Manim animations for algebraic derivations, Basel-style proofs, series expansions, inequality proofs, or any step-by-step mathematical animation.
metadata:
  type: reference
  tags: [manim, algebra, derivation, animation, horizontal, bigfont, proof, graph, skill]
---

# 横屏大字 Manim 代数动画 Skill

基于"巴塞尔问题 arcsin 泰勒展开证明"完整动画提炼。核心特点：横屏大字、公式加粗、每页 ≤4 行均匀分布、图像+推导双模式。

---

## 1. 全局配置（横屏 16:9）

```python
from manim import *
import numpy as np

config.pixel_width = 1920
config.pixel_height = 1080
config.frame_width = 16.0
config.frame_height = 9.0
```

渲染命令：
```bash
manim file.py ClassName -ql     # 低清预览 (480p)
manim file.py ClassName -pqh    # 高清渲染 (1080p60)
```

---

## 2. 配色与常量

```python
ZH_FONT = "KaiTi"
BG     = "#0F1720"   # 深蓝黑背景
INK    = "#F6F2EA"   # 暖白正文
MUTED  = "#A9B4C2"   # 灰字辅助
BLUE   = "#5DADEC"   # 标题/步骤
GREEN  = "#66D19E"   # 结论/答案
YELLOW = "#FFD166"   # 核心公式高亮
ORANGE = "#F59E62"   # 辅助强调
RED    = "#FF6B6B"   # 警示/重点
VIOLET = "#B79CFF"   # 备选
READ_PAUSE = 1.6     # 公式阅读停顿
```

---

## 3. 辅助方法模板

### 3.1 中文文本

```python
def zh(self, content, font_size=42, color=INK, weight=NORMAL):
    return Text(content, font=ZH_FONT, font_size=font_size, color=color, weight=weight)
```

### 3.2 数学公式（加粗描边）

```python
def mt(self, content, font_size=56, color=INK, stroke_width=1):
    return MathTex(content, font_size=font_size, color=color, stroke_width=stroke_width)

def mt_small(self, content, font_size=50, color=INK):
    return self.mt(content, font_size=font_size, color=color)
```

- `stroke_width=1` 让公式线条略粗，横屏大字下更清晰
- 默认字号 56，长公式用 `mt_small`（50~54）

### 3.3 混合排版（中文+公式同行）

```python
def mixed(self, *items, text_size=38, math_size=44, buff=0.08):
    parts = []
    for kind, content, color in items:
        if kind == "text":
            parts.append(self.zh(content, font_size=text_size, color=color))
        else:
            parts.append(self.mt(content, font_size=math_size, color=color))
    return VGroup(*parts).arrange(RIGHT, buff=buff)
```

### 3.4 自动缩放

```python
def fit(self, mob, width=None, height=None):
    target_width = width if width is not None else config.frame_width - 1.2
    target_height = height if height is not None else config.frame_height - 1.0
    if mob.width > target_width:
        mob.scale_to_fit_width(target_width)
    if mob.height > target_height:
        mob.scale_to_fit_height(target_height)
    return mob
```

### 3.5 标题栏（纯文字，无下划线）

```python
def title_bar(self, text, color=BLUE):
    title = self.zh(text, font_size=52, color=color, weight=BOLD)
    title.to_edge(UP, buff=0.38)
    return VGroup(title)
```

**要点**：标题无下划线，避免与大字重叠。如需标题含公式（如 α=-1/2），用 VGroup 组装：

```python
t1 = self.zh("代入 ", font_size=52, color=BLUE, weight=BOLD)
t2 = MathTex(r"\alpha=-\frac{1}{2}", font_size=52, color=BLUE, stroke_width=1)
t3 = self.zh(", ", font_size=52, color=BLUE, weight=BOLD)
t4 = MathTex(r"u=-x^2", font_size=52, color=BLUE, stroke_width=1)
bar = VGroup(t1, t2, t3, t4).arrange(RIGHT, buff=0.08)
bar.to_edge(UP, buff=0.38)
```

### 3.6 内容纵向均匀分布

```python
def layout_below(self, bar, *lines):
    """在标题栏下方均匀分布内容行，≤4 行时纵向分散"""
    n = len(lines)
    for line in lines:
        self.fit(line, width=config.frame_width - 1.2)
    if n <= 2:
        buff = 1.1
    elif n == 3:
        buff = 0.95
    else:
        buff = 0.78
    content = VGroup(*lines).arrange(DOWN, buff=buff, aligned_edge=LEFT)
    content.next_to(bar, DOWN, buff=0.7)
    return content
```

**铁律**：每页内容 ≤4 行（公式+文字各算一行），推荐 3 行（最舒适）。4 行仅用于短公式。

### 3.7 动画快捷方法

```python
def wait_formula(self):
    self.wait(READ_PAUSE)

def write_formula(self, mob, run_time=0.9):
    self.play(Write(mob), run_time=run_time)
    self.wait_formula()

def write_text(self, mob, run_time=0.75):
    self.play(Write(mob), run_time=run_time)

def clear_scene(self):
    if self.mobjects:
        self.play(*[FadeOut(mob) for mob in self.mobjects], run_time=0.5)
```

**每个场景末尾**：`self.wait(2.0)` → `self.clear_scene()`

---

## 4. 横屏大字字号速查表

| 元素 | 方法 | font_size | 颜色 |
|------|------|-----------|------|
| 开场主标题 | `zh(weight=BOLD)` | 56~62 | INK |
| 章节标题栏 | `zh(weight=BOLD)` | 52 | BLUE |
| 核心结论公式 | `mt()` | 60~64 | YELLOW/GREEN |
| 普通推导公式 | `mt()` | 54~58 | INK |
| 长公式（多分式） | `mt_small()` | 50~52 | INK |
| 极长公式 | `mt_small()` | 46~50 | INK |
| 混合行中文 | `mixed(text_size=)` | 36~40 | INK |
| 混合行公式 | `mixed(math_size=)` | 42~46 | YELLOW |
| 辅助注释 | `zh()` | 32~36 | MUTED |
| 图像标签 | `mt()` | 26~30 | 曲线同色 |

---

## 5. 行数控制与间距

```
每页 ≤ 4 行（推荐 3 行），公式文字各算一行
2行 → buff=1.1
3行 → buff=0.95  
4行 → buff=0.78

标题到首行：buff=0.7
fit 边距：config.frame_width - 1.2
```

**当第4行溢出时**：
- 拆为两页（各3行）
- 或合并短行为一行（VGroup arrrange RIGHT）
- 或缩字号 2~4pt

---

## 6. 中文 + 公式混排规则

### 绝对禁止
```python
# ❌ MathTex 中 \text{中文} 导致 LaTeX 报错
r"\text{令 } x = \sin t"
r"\text{完美抵消！}"
```

### 正确做法：VGroup 组装
```python
# ✅ VGroup(Text + MathTex)
step_label = self.zh("令 ", font_size=42, color=INK)
step_math = self.mt_small(r"x = \sin t", font_size=52, color=INK)
step = VGroup(step_label, step_math).arrange(RIGHT, buff=0.1)

# ✅ 多段组装
t1 = self.zh("在 ", font_size=36, color=INK)
t2 = self.mt_small(r"[0, \tfrac{\pi}{2}]", font_size=46, color=INK)
t3 = self.zh(" 上积分，左边 = ", font_size=36, color=INK)
t4 = self.mt(r"\frac{\pi^2}{8}", font_size=58, color=GREEN)
row = VGroup(t1, t2, t3, t4).arrange(RIGHT, buff=0.08)
```

### 两行合并为一行
```python
# 左侧公式 + 箭头 + 右侧结论
left = self.mt(r"S = \frac{\pi^2}{8} + \frac{1}{4}S", font_size=54, color=INK)
arrow = self.mt(r"\;\Longrightarrow\;", font_size=50, color=ORANGE)
right = self.mt(r"\frac{3}{4}S = \frac{\pi^2}{8},\; S = \frac{\pi^2}{6}", font_size=54, color=GREEN)
row = VGroup(left, arrow, right).arrange(RIGHT, buff=0.25)
```

---

## 7. 图像/绘图模式

### 7.1 坐标轴 + 曲线

```python
axes = Axes(
    x_range=[-1.6, 1.6, 0.5],
    y_range=[-1.8, 1.8, 0.5],
    x_length=8.5, y_length=5.5,
    axis_config={"color": MUTED, "stroke_width": 2},
)
axes.move_to([-1.5, -0.2, 0])   # 左侧留空给标签

# 真实曲线
true_curve = axes.plot(
    lambda x: np.arcsin(x) if abs(x) <= 1 else np.nan,
    x_range=[-0.99, 0.99],
    color=INK, stroke_width=5,
)

# 近似曲线
approx = axes.plot(
    lambda x: poly(x, n), x_range=[-0.99, 0.99],
    color=BLUE, stroke_width=4,
)
```

### 7.2 多标签网格排列（第四象限）

标签放右下角，避免与曲线重叠，排成 2 行网格：
```python
row1_y = axes.c2p(0, -0.5)[1]    # 上行 y
row2_y = axes.c2p(0, -0.95)[1]   # 下行 y
start_x = axes.c2p(0.4, 0)[0]    # 左边界 x

# Row1: label_0 | label_2
label_0.move_to([start_x, row1_y, 0], aligned_edge=LEFT)
label_2.next_to(label_0, RIGHT, buff=0.5)

# Row2: label_1 | label_3 | label_4
label_1.move_to([start_x, row2_y, 0], aligned_edge=LEFT)
label_3.next_to(label_1, RIGHT, buff=0.5)
label_4.next_to(label_3, RIGHT, buff=0.45)
```

---

## 8. 场景结构骨架

```python
class MyProof(Scene):
    # === 辅助方法 ===
    def zh(self, ...): ...
    def mt(self, ...): ...
    def mt_small(self, ...): ...
    def mixed(self, ...): ...
    def fit(self, ...): ...
    def title_bar(self, ...): ...
    def layout_below(self, ...): ...
    def wait_formula(self): ...
    def write_formula(self, ...): ...
    def write_text(self, ...): ...
    def clear_scene(self): ...

    # === 主流程 ===
    def construct(self):
        self.camera.background_color = BG
        self.opening()
        self.step_one()
        self.step_two()
        self.graph_scene()
        self.step_three()
        self.conclusion()

    def opening(self):
        title = self.zh("标题", font_size=58, color=INK, weight=BOLD)
        title.to_edge(UP, buff=0.5)
        # ... 题目 + 方法标签 ...
        self.wait(2.0)
        self.clear_scene()

    def step_one(self):
        bar = self.title_bar("第X步：xxx")
        self.play(Write(bar), run_time=0.8)
        # 3~4 行公式，用 layout_below 分布
        line1 = self.mt(...)
        line2 = self.mt(...)
        line3 = self.mt(...)
        content = self.layout_below(bar, line1, line2, line3)
        for line in [line1, line2, line3]:
            self.write_formula(line)
        self.wait(2.0)
        self.clear_scene()

    def graph_scene(self):
        """专用图像页：坐标轴 + 曲线 + 标签"""
        bar = self.title_bar("图像标题")
        self.play(Write(bar), run_time=0.8)
        # Axes + curves + labels ...
        self.wait(2.0)
        self.clear_scene()

    def conclusion(self):
        bar = self.title_bar("结论", color=GREEN)
        self.play(Write(bar), run_time=0.8)
        # 最终答案 + 方法回顾 + SurroundingRectangle
        self.wait(READ_PAUSE)
```

---

## 9. 运行检查清单

1. `python -c "compile(open('f.py',encoding='utf-8').read(),'f.py','exec')"` — 语法
2. 检查：MathTex 中有没有 `\text{中文}`？（必须为 0）
3. 检查：标题栏有无下划线？（应该无）
4. 检查：每页内容行是否 ≤4？（推荐 3 行）
5. 检查：`construct()` 第一行 `self.camera.background_color = BG`？
6. 检查：每个场景末尾 `self.wait(2.0)` + `self.clear_scene()`？
7. 检查：图像标签是否与曲线/坐标轴重叠？
8. `manim f.py ClassName -ql` — 低清预览
9. `manim f.py ClassName -pqh` — 1080p60 高清

---

## 10. 几何绘图铁律：精确计算，标签写对

画三角形、内切圆、外接圆等几何图形时，**禁止用目测坐标**。

### 10.1 内切圆必须精确相切

```python
# 用三边 + 内心公式精确计算
a = float(np.linalg.norm(B - C))   # 对顶点 A 的边
b = float(np.linalg.norm(C - A))   # 对顶点 B 的边
c = float(np.linalg.norm(A - B))   # 对顶点 C 的边
peri = a + b + c
# 面积 (Shoelace)
area = 0.5 * abs(
    A[0]*(B[1]-C[1]) + B[0]*(C[1]-A[1]) + C[0]*(A[1]-B[1])
)
# 内心坐标（加权平均）
incenter = np.array([
    (a*A[0] + b*B[0] + c*C[0]) / peri,
    (a*A[1] + b*B[1] + c*C[1]) / peri,
    0,
])
inradius = float(2 * area / peri)

incircle = Circle(arc_center=incenter, radius=inradius, ...)
```

### 10.2 切点要标出，段长标签要放对位置

```python
# 内心到三边的垂足 = 三个切点
def foot_to_line(P, Q, I):
    d = Q - P
    t = float(np.dot(I - P, d) / np.dot(d, d))
    t = max(0, min(1, t))
    return P + t * d

T_AB = foot_to_line(A, B, incenter)
T_AC = foot_to_line(A, C, incenter)
T_BC = foot_to_line(B, C, incenter)

# 切点圆点 + 段长标签放在线段中点外侧
# 切线长定理：同顶点出发的两段相等
# A→T_AB = A→T_AC = x, B→T_AB = B→T_BC = y, C→T_AC = C→T_BC = z
```

---

## 11. 视频输出到桌面

渲染完成后，将视频文件拷贝到用户桌面：

```bash
manim file.py ClassName -pqh
cp "media/videos/ClassName/1080p60/ClassName.mp4" "/c/Users/123/Desktop/"
```

---

## 12. 思路分析页 + VGroup 混排防乱码

### 12.1 抄题后必须写思路分析页

开场抄题后、正式推导前，加一页思路分析（4 行，不同颜色），梳理论证脉络。

### 12.2 思路分析行 = VGroup(Text + MathTex)

公式部分必须用 `MathTex`（LaTeX 渲染），禁止把公式写在 `Text()` 里（会导致根号残缺、平方变成乱码）。

```python
def strategy(self):
    bar = self.title_bar("证明思路分析")
    self.play(Write(bar), run_time=0.8)

    s1 = self.zh("一、基础版：余弦定理 → 放缩 → 消元化为仅含角 C", font_size=38, color=BLUE)

    s2 = VGroup(
        self.zh("二、辅助角公式 ", font_size=38, color=GREEN),
        self.mt(r"\sqrt{3}\sin C+\cos C=2\sin(C+30^\circ)\le 2", font_size=42, color=INK),
        self.zh(" 恒成立", font_size=38, color=GREEN),
    ).arrange(RIGHT, buff=0.08)

    s3 = VGroup(
        self.zh("三、加强版：Ravi 代换 ", font_size=38, color=ORANGE),
        self.mt(r"a=y+z", font_size=42, color=INK),
        self.zh(" → 海伦 → 平方去根号", font_size=38, color=ORANGE),
    ).arrange(RIGHT, buff=0.08)

    s4 = VGroup(
        self.zh("四、均值收尾 ", font_size=38, color=VIOLET),
        self.mt(r"x^2y^2+y^2z^2\ge 2xy^2z", font_size=42, color=INK),
        self.zh(" × 3 → 相加得证", font_size=38, color=VIOLET),
    ).arrange(RIGHT, buff=0.08)

    content = self.layout_below(bar, s1, s2, s3, s4)
    for line in [s1, s2, s3, s4]:
        self.play(Write(line), run_time=0.9)
    self.wait(2.0)
    self.clear_scene()
```

**核心原则**：凡是含公式的 Text，拆成 VGroup(Text + MathTex + Text + …)，每个 MathTex 只写纯 LaTeX（ASCII），确保渲染不乱码。
