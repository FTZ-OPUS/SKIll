# 冰河API聚合平台接入 ZCode 技能文档（MiniMax-M3 + Gemini-3.8-Flash）

> 用途：换电脑 / 分享给其他 AI 时，把本文丢给它，即可照着完成接入。
> 平台网址：**https://api.bingheai.org**（冰河 API 聚合平台）
> 免费模型：MiniMaxAI/MiniMax-M3、gemini-3.8-flash-high（均 ¥0，多模态）
> 实测日期：2026-09-10（两个模型的对话、图片识别、推理参数均已实测通过）

---

## 一、平台与前置信息

**冰河 API 聚合平台网址：https://api.bingheai.org**

| 项 | 值 |
|---|---|
| OpenAI 兼容端点 | `https://api.bingheai.org/v1` |
| 认证方式 | HTTP Header：`Authorization: Bearer <你的key>` |
| key 获取 | 平台控制台 → API 密钥 → 创建（sk- 开头） |
| 免费额度 | MiniMax-M3 输入输出 0 元；Gemini-3.8-Flash ¥0/请求；可开无限额 key |

## 二、本平台的两个免费模型

| 模型 ID | 上下文 | 输出 | 模态 | 能力 |
|---|---|---|---|---|
| `MiniMaxAI/MiniMax-M3` | 1M tokens | 128K | 文本/图片/视频 | 深度思考、工具调用、代码与 Agent |
| `gemini-3.8-flash-high` | 1M tokens | 64K | 文本/图片/视频 | "多模态之王"、深度思考 |

## 三、接入前的验证（先跑通再配置）

```bash
# 1. key 有效性 + 模型列表（看到两个模型 ID 即通过）
curl https://api.bingheai.org/v1/models -H "Authorization: Bearer sk-你的key"

# 2. MiniMax-M3 对话连通性
curl https://api.bingheai.org/v1/chat/completions \
  -H "Authorization: Bearer sk-你的key" -H "Content-Type: application/json" \
  -d '{"model":"MiniMaxAI/MiniMax-M3","messages":[{"role":"user","content":"回复两个字：正常"}],"max_tokens":50}'

# 3. Gemini-3.8-Flash 对话连通性（模型 ID 换成 gemini-3.8-flash-high 即可）
# 4. 多模态（可选）：请求体 content 里带 base64 图片问颜色，实测两模型均识别准确
# 5. 推理参数（可选）：请求体加 "reasoning_effort":"high"，正常返回即兼容
```

## 四、ZCode 配置的两个必知规则

1. **供应商 ID 必须 `custom:` 前缀**：`builtin:` 是 ZCode 内置供应商专属白名单，自定义供应商写 `builtin:` 会被注册表静默丢弃（界面能看到、运行时找不到）。
2. **`kind` 必须用 `openai-compatible`**：写 `openai` 会走 OpenAI Responses 接口（部分平台不支持）→ 报 `Model request failed`；`openai-compatible` 走 Chat Completions 接口，兼容性最好。

## 五、配置 ZCode（手动方式，一个 provider 装两个模型）

1. 备份：`cp ~/.zcode/v2/config.json ~/.zcode/v2/config.json.bak`
2. 编辑 `~/.zcode/v2/config.json`，在 `"provider"` 对象中新增：

```json
"custom:binghe": {
  "name": "BingHe",
  "kind": "openai-compatible",
  "options": {
    "apiKey": "sk-你的key",
    "baseURL": "https://api.bingheai.org/v1"
  },
  "enabled": true,
  "source": "custom",
  "models": {
    "MiniMaxAI/MiniMax-M3": {
      "reasoning": { "enabled": true, "variants": ["low", "max", "high"], "defaultVariant": "max" },
      "limit": { "context": 1000000, "output": 131072 },
      "modalities": { "input": ["text", "image", "video"], "output": ["text"] },
      "zcode": { "modified": false, "priority": 91 }
    },
    "gemini-3.8-flash-high": {
      "reasoning": { "enabled": true, "variants": ["low", "max", "high"], "defaultVariant": "max" },
      "limit": { "context": 1000000, "output": 65536 },
      "modalities": { "input": ["text", "image", "video"], "output": ["text"] },
      "zcode": { "modified": false, "priority": 90 }
    }
  }
}
```

> 同平台多个模型共用一个 provider（`custom:binghe`），后续加新模型只需在 `models` 里加对象，不要重复创建 provider。

3. 校验 JSON：`python3 -c "import json; json.load(open('/Users/<你的用户名>/.zcode/v2/config.json'))"`
4. 完全重启 ZCode：`osascript -e 'quit app "ZCode"' && sleep 4 && open <ZCode.app路径>`（注册表只在启动时构建，改完必须重启）

## 六、验证是否成功

1. ZCode **新建会话**，分别选 `BingHe / MiniMaxAI/MiniMax-M3` 和 `BingHe / gemini-3.8-flash-high`，发消息能回复即成功
2. 查日志确认注册表已加载：

```bash
grep -a "readState 完成" ~/.zcode/v2/logs/$(date +%F).log | tail -1
# 期望：providerCount +1（首次）、modelCount +2，无 unavailable 报错
```

## 七、常见问题

| 现象 | 原因 / 解决 |
|---|---|
| `Model request failed` | `kind` 写成了 `openai`，改成 `openai-compatible` 并重启 |
| 界面能看到、一用就报错 | 供应商 ID 不是 `custom:` 前缀 |
| 401 / Invalid key | key 复制不完整，回控制台重新复制 |
| 改完没生效 | 没完全重启 ZCode（模型注册表只在启动时构建） |

## 八、快捷信息（给 AI 的一句话版）

冰河 API 聚合平台 `https://api.bingheai.org`，OpenAI 兼容端点 `https://api.bingheai.org/v1`（Bearer 认证），模型 `MiniMaxAI/MiniMax-M3` 和 `gemini-3.8-flash-high`（均 1M 上下文、text+image+video、免费），写入 `~/.zcode/v2/config.json` 的 `provider.custom:binghe.models`（两个模型共用一个 provider），注意 `custom:` 前缀 + `kind: openai-compatible`，改完重启 ZCode。
