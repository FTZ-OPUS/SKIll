# 教资简答题 LaTeX 排版规范

> 适用场景：将 Markdown 格式的简答题押题文档转为护眼背诵版 PDF。  
> 编译引擎：`xelatex`（中文必须）  
> 文档类：`ctexart`

---

## 1. 字体设置

```latex
\setCJKmainfont{Kaiti SC}
```

- 中文主字体为**楷体-简（Kaiti SC）**，笔画粗、不虚，适合长时间阅读。
- macOS 系统自带此字体，Windows/Linux 用户需替换为本地可用楷体（如 `STKaiti`、`SimKai`）。

---

## 2. 页面与边距

```latex
\documentclass[12pt,a4paper]{ctexart}
\usepackage[margin=2.5cm]{geometry}
```

- A4 纸，12pt 字号，四边边距 2.5cm。

---

## 3. 护眼底色（极浅绿）

```latex
\definecolor{lightgreen}{HTML}{F1F8F2}
```

- 背景色为 `#F1F8F2`——极浅的绿，几乎接近白皮，铺在答案框内部，长时间盯着不刺眼。

---

## 4. 答案框样式

```latex
\newtcolorbox{answerbox}[1][]{
    enhanced, breakable,
    colback=lightgreen, colframe=ptgreen!50!black,
    title={\color{white}\bfseries #1},
    attach boxed title to top left={xshift=3mm,yshift=-3mm},
    boxed title style={colback=ptgreen,sharp corners},
    fonttitle=\large,
    before skip=12pt, after skip=12pt
}
```

- **每道题的答案**放入 `answerbox`，标题为题干（如"1. 简述..."），标题栏为深绿色底白字。
- 框内底色为 `lightgreen`（#F1F8F2），边框为深绿。
- `breakable` 允许跨页断框。

---

## 5. 章节标题框

```latex
\newtcolorbox{chapterbox}[1][]{
    enhanced, breakable,
    colback=lightgreen, colframe=ptblue!60!black,
    title={\color{white}\bfseries #1},
    attach boxed title to top center={xshift=0mm,yshift=-3mm},
    boxed title style={colback=ptblue,sharp corners,size=small},
    fonttitle=\Large\centering,
    before skip=16pt, after skip=12pt
}
```

- 每章开头用蓝色大标题框（如"第一章 教育基础知识"），蓝色底白字，居中。
- 框内底色同样为浅绿。

---

## 6. 页眉页脚

```latex
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\color{ptblue}2026下教资押题 · 47道简答题}
\fancyhead[R]{\color{ptblue}\thepage}
\renewcommand{\headrulewidth}{0.5pt}
\renewcommand{\headrule}{\hbox to\headwidth{\color{ptblue}\leaders\hrule height 0.5pt\hfill}}
```

- 左侧页眉为文档标题，右侧为页码，分隔线为蓝色细线。

---

## 7. 封面

```latex
\begin{titlepage}
    \centering\vspace*{3cm}
    {\Huge\bfseries\color{ptblue} 2026下教资押题}
    \vspace{0.5cm}
    {\Huge\bfseries\color{ptgreen} 47道简答题}
    \vspace{1cm}
    {\Large\color{gray} coco 与粉笔重合（新整理，供参考）}
    \vspace{2cm}
    {\large\color{gray} 涵盖：教育基础知识、中学课程、中学教学}
    \vspace{0.3cm}
    {\large\color{gray} 中学生学习心理、中学生发展心理、中学生心理辅导}
    \vspace{0.3cm}
    {\large\color{gray} 中学德育、中学班级管理与教师心理}
    \vfill
    {\small\color{gray}\today}
\end{titlepage}
```

---

## 8. 颜色定义汇总

```latex
\definecolor{ptred}{HTML}{D64545}
\definecolor{ptgold}{HTML}{D4A017}
\definecolor{ptgreen}{HTML}{2E8B57}
\definecolor{ptblue}{HTML}{3A7CA5}
\definecolor{ptpurple}{HTML}{7B3F8C}
\definecolor{ptteal}{HTML}{008080}
\definecolor{ptorange}{HTML}{E07020}
\definecolor{ptbg}{HTML}{F8F5F0}
\definecolor{lightgreen}{HTML}{F1F8F2}   % 答案框/章节框底色（护眼关键）
```

---

## 9. 文档结构模板

```
封面（titlepage）
  ↓
第一章标题（chapterbox）
  ↓
第1题（answerbox）→ 第2题 → ... → 本章最后一题
  ↓
第二章标题（chapterbox）
  ↓
第1题（answerbox）→ ...
  ↓
...以此类推
```

---

## 10. 编译命令

```bash
cd /path/to/project
xelatex -interaction=nonstopmode main.tex   # 第一遍
xelatex -interaction=nonstopmode main.tex   # 第二遍（更新交叉引用）
```

编译两遍确保页码和目录正确。

---

## 11. 给 AI 的转换指令

将以上规范交给 AI 时，可附上以下提示词：

> 读取 Markdown 格式的简答题文档，按照《教资简答题LaTeX排版规范.md》转为 LaTeX 源文件，编译为 PDF 放到桌面。关键要求：
> 1. 中文字体用楷体（Kaiti SC）
> 2. 每个答案放入浅绿底色的 tcolorbox（#F1F8F2）
> 3. 章节标题用蓝色大框
> 4. 页眉页脚带页码和文档名
> 5. 编译引擎 xelatex，编译两遍
