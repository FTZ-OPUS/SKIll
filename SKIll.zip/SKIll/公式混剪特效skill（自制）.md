---
name: formula-mixcut-animation
description: 公式混剪爆款 Manim 定稿技能 — 壁纸幽灵层、金橙渐变、快速形变转场（transform_mismatches 灵魂参数）、1秒/卡节奏、绘图页插入、数据驱动。以《概率统计考试神公式》成品（22卡+2绘图页/29.3s）验证定稿。Use when making fast-paced formula showcase/mixcut videos.
metadata:
  type: reference
  tags: [manim, formula, mixcut, transform, fast-paced, wallpaper]
---

# 公式混剪 Manim Skill（成品定稿版）

以成品《概率统计考试神公式》（22 张公式卡 + 2 张绘图页，29.3s，1920×1080 60fps）逆向并验证。
节奏基准来自爆款样本实测：**14 卡 / 14.4s ≈ 1.03s/卡**。慢速讲解版节奏已废弃，本 skill 只保留这一种速度。

---

## 1. 全局配置

```python
from manim import *
import numpy as np

config.pixel_width  = 1920
config.pixel_height = 1080
config.frame_width  = 16.0
config.frame_height = 9.0
# 背景近黑 #050505（壁纸层垫底，见 §3）
```

## 2. 节奏（铁律中的铁律）

```python
T_RUN  = 0.45   # 形变时长
T_HOLD = 0.55   # 停留时长
# 卡片循环 = 1.0s，与样本 1.03s/卡一致
```

- 开场 ≤ 2s（大标题一闪 + 一句副标题，直接融入第一张卡）
- 结尾 ≤ 2s（含 0.4s 黑场淡出）
- **总时长公式：卡数 × 1.0s + 绘图页数 × 2.5s + 4s**

## 3. 画面三层结构 + 壁纸层

每张卡只有三层，**同屏永远只允许一张卡**（护眼核心）：

| 层 | 内容 | 规格 |
|----|------|------|
| 标题 | 固定前缀 + 主题名 | 顶部居中 `to_edge(UP, buff=0.45)`，楷体 60 加粗；前缀黄绿 `#CDDC39`，主题名金橙渐变 `#FFD166→#F59E62` |
| 公式 | 单条 LaTeX | 居中 `UP*0.55`，`MathTex(font_size=64, stroke_width=1.2)`，橙金渐变 `#FF8A50→#FFD166`，超宽则 `scale_to_fit_width(14.4)` |
| 副标题 | 两行短句 | `DOWN*2.35`，第一行绿 `#66D19E` 34 加粗，第二行青 `#4DB6AC` 26 |

**壁纸幽灵层**（最先 add，全程静止）：
- 25~30 条灰色 `MathTex`，字号 34~48 随机，`set_opacity(0.10)`，随机散布 `[-7.1,7.1]×[-4,4]`、微旋转 ±0.12rad
- 用固定随机种子保证可复现；内容取卡片公式的"变体"（积分、极限、分布记号等）
- **opacity ≤ 0.12、绝不参与形变、绝不移动**

## 4. 转场（灵魂，实测踩坑结论）

```python
def morph_to(self, new_t, new_f, new_s, run_time=T_RUN):
    self.play(
        ReplacementTransform(self.cur_t, new_t),                  # 中文标题整族字形拉伸
        TransformMatchingTex(self.cur_f, new_f,
                             transform_mismatches=True),          # ★灵魂参数
        ReplacementTransform(self.cur_s, new_s),                  # 副标题同法
        run_time=run_time,
    )
```

- ★ `transform_mismatches=True` **必须加**：默认行为会把对不上的碎片淡出淡入，观感是"一条公式弹出另一条"；加上后所有碎片互相形变——旧字形拉伸、旋转、飞向新位置，新旧公式中途共存叠影，与爆款样本逐帧一致
- 中文 `Text` 用 `ReplacementTransform` 整族形变（字符数不同自动复制拉伸，产生拉丝感）；`TransformMatchingShapes` 会淡掉不匹配字形，效果偏温和，弃用
- 上一卡的 mob 直接作为 transform 源，**绝不 FadeOut 再 Write**
- 标题、公式、副标题三路**同一拍**形变，节奏才连得上
- 首卡公式用 `FadeIn(shift=DOWN*0.3)` 进场（与标题形变同拍）；末卡淡出收黑

## 5. 数据驱动（加卡 = 加一行）

```python
CARDS = [
    ("容斥公式",  r"P(A\cup B)=P(A)+P(B)-P(AB)", "三事件：加减交替进行", "集合思想"),
    ("贝叶斯公式", r"P(A_j\,|\,B)=\frac{P(A_j)P(B\,|\,A_j)}{P(B)}", "先验变后验", "由果溯因"),
    # (标题, 公式, 副标题1, 副标题2) ...
]
for i, card in enumerate(CARDS):
    if i == 0: continue
    self.go_card(i)        # 或插入绘图页
```

- LaTeX 禁止 `\text{中文}`；中文一律 `Text`，数学符号（λ、σ、²、±、→）实测楷体可直出
- 卡片可带双式（如 `P(X=k)=..., E(X)=np` 一行放下），超宽靠 fit 缩放

## 6. 绘图页（从"展馆风"样本借来的加分项，每张 ≤ 2.5s）

在卡片流中插入 1~3 张绘图页，位置选在该主题的第一张卡之前：

```python
def graph_bell(self):
    self.morph_to(标题, 公式(移到 DOWN*1.55), 副标题)      # 三路照常形变
    axes + 曲线 Create(0.45) → 分区着色 FadeIn(0.3) → 标签 FadeIn(0.25) → wait(0.7)
    self.pending_fade = [全部图元素]                        # 下一张卡的 morph_to 里同拍散场
```

- 正态钟形 3σ 着色：内带绿 `#66D19E`、中带橙 `#F59E62`、外带红 `#FF6B6B`，百分比标签直接压在色带上
- CLT 柱状图：13 根橙柱 + ParametricFunction 钟形曲线从柱顶掠过
- 图元素通过 `pending_fade` 挂到**下一卡的形变拍里**一起散场，不单独占时间
- 标注文字放图内空白区（如柱顶上方），防止与副标题相撞

## 7. 制作流水线（检查清单）

1. 写 `CARDS` 数据 → 组装代码（§5 模板）
2. `python3 -c "compile(...)"` 语法检查；正则查 `\text{中文}` 必须为 0
3. `-ql` 低清渲染 → ffprobe 核对时长 ≈ 卡数×1.0 + 绘图页×2.5 + 4
4. ffmpeg 抽帧：**停留期帧**查排版/遮挡/越界，**形变中点帧**查转场炫度
5. 修完 → `-pqh` 1080p60 高清 → 直接拷到 `~/Desktop/`（用户自行归档）
6. 删除 media 缓存等中间产物，只留：源码 .py、成品视频、本文档

## 8. 渲染与交付

```bash
~/venvs/manim/bin/manim f.py ClassName -pqh --disable_caching
cp media/videos/f/1080p60/ClassName.mp4 ~/Desktop/        # 直接放桌面，不建子文件夹
```

- 环境：`~/venvs/manim`（Python 3.12 + Manim CE 0.21）、TeX Live 2026、ffmpeg；中文楷体用 `"Kaiti SC"`
- 中文字体必须先渲染冒烟测试（Windows 下 KaiTi / macOS 下 Kaiti SC，跨平台要换名）
